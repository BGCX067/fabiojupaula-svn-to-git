INSERT INTO ATOR (nomeAtor) VALUES ('KEANU REAVES');
INSERT INTO Ator (nomeAtor) VALUES ('LAURENCE FISHBURNE');
INSERT INTO ATOR (nomeAtor) VALUES ('CARRIE-ANNE MOSS');
INSERT INTO Ator (nomeAtor) VALUES ('HUGO WEAVING'); 
INSERT INTO Ator (nomeAtor) VALUES ('Rachel Weisz');
INSERT INTO ATOR (nomeAtor) VALUES ('Djimon Hounson');
INSERT INTO Ator (nomeAtor) VALUES ('Elijah Wood');
INSERT INTO ATOR (nomeAtor) VALUES ('Ian McKellen');
INSERT INTO Ator (nomeAtor) VALUES ('Orlando Bloom'); 
INSERT INTO Ator (nomeAtor) VALUES ('Cate Blanchett');
INSERT INTO ATOR (nomeAtor) VALUES ('Natalie Portman');
INSERT INTO Ator (nomeAtor) VALUES ('Stephen Rea');
INSERT INTO ATOR (nomeAtor) VALUES ('John Hurt');
INSERT INTO Ator (nomeAtor) VALUES ('Roger Allam'); 
INSERT INTO Ator (nomeAtor) VALUES ('Ewan McGregor');
INSERT INTO ATOR (nomeAtor) VALUES ('Hayden Christensen');
INSERT INTO Ator (nomeAtor) VALUES ('Ian McDiarmid');
INSERT INTO ATOR (nomeAtor) VALUES ('Samuel L. Jackson');
INSERT INTO Ator (nomeAtor) VALUES ('Christopher Lee'); 
INSERT INTO Ator (nomeAtor) VALUES ('Frank Oz');

INSERT INTO Diretor (nomeDiretor) VALUES ('Andy Wachowski');
INSERT INTO Diretor (nomeDiretor) VALUES ('Larry Wachowski');
INSERT INTO Diretor (nomeDiretor) VALUES ('Francis Lawrence');
INSERT INTO Diretor (nomeDiretor) VALUES ('Peter Jackson'); 
INSERT INTO Diretor (nomeDiretor) VALUES ('James McTeigue');
INSERT INTO Diretor (nomeDiretor) VALUES ('George Lucas');

INSERT INTO DVD (tituloPort,tituloIng,tipo,genero,ano) VALUES ('Matrix','The Matrix','D','Ficção',1999);
INSERT INTO DVD (tituloPort,tituloIng,tipo,genero,ano) VALUES ('Costantine','Constantine','D','Aventura',2005);
INSERT INTO DVD (tituloPort,tituloIng,tipo,genero,ano) VALUES ('O Senhor dos Anéis: A Sociedade do Anel','The Lord of the Rings: The Fellowship of the Ring','B','Aventura',2001);
INSERT INTO DVD (tituloPort,tituloIng,tipo,genero,ano) VALUES ('V de Vingança','V for Vendetta','D','Ficção',2005);
INSERT INTO DVD (tituloPort,tituloIng,tipo,genero,ano) VALUES ('Star Wars: Episódio III - A Vingança dos Sith','Star Wars: Episode III - Revenge of the Sith','B','Ficção',2005);

INSERT INTO Amigo VALUES ('12345678911','ZE','RUA Z NRO 15','2198765432',NULL,NULL);
INSERT INTO Amigo VALUES ('12345378911','JOÃO','RUA A NRO 15','2198765433',NULL,NULL);
INSERT INTO Amigo VALUES ('12345478911','MARA','RUA B NRO 15','2198765434',NULL,NULL);
INSERT INTO Amigo VALUES ('12345978911','PEDRO','RUA C NRO 15','2198765452',NULL,NULL);
INSERT INTO Amigo VALUES ('12345178911','LAURA','RUA D NRO 15','2198765462',NULL,NULL);
INSERT INTO Amigo VALUES ('12345378921','LIKA','RUA E NRO 15','2198765437',NULL,NULL);

INSERT INTO diretorParticipa VALUES (1,1);
INSERT INTO diretorParticipa VALUES (1,2);
INSERT INTO diretorParticipa VALUES (2,3);
INSERT INTO diretorParticipa VALUES (3,4);
INSERT INTO diretorParticipa VALUES (4,5);
INSERT INTO diretorParticipa VALUES (5,6);

INSERT INTO atorParticipa VALUES (1,1);
INSERT INTO atorParticipa VALUES (1,2);
INSERT INTO atorParticipa VALUES (1,3);
INSERT INTO atorParticipa VALUES (1,4);

INSERT INTO atorParticipa VALUES (2,1);
INSERT INTO atorParticipa VALUES (2,5);
INSERT INTO atorParticipa VALUES (2,6);

INSERT INTO atorParticipa VALUES (3,7);
INSERT INTO atorParticipa VALUES (3,8);
INSERT INTO atorParticipa VALUES (3,9);
INSERT INTO atorParticipa VALUES (3,10);

INSERT INTO atorParticipa VALUES (4,4);
INSERT INTO atorParticipa VALUES (4,11);
INSERT INTO atorParticipa VALUES (4,12);
INSERT INTO atorParticipa VALUES (4,13);
INSERT INTO atorParticipa VALUES (4,14);

INSERT INTO atorParticipa VALUES (5,11);
INSERT INTO atorParticipa VALUES (5,15);
INSERT INTO atorParticipa VALUES (5,16);
INSERT INTO atorParticipa VALUES (5,17);
INSERT INTO atorParticipa VALUES (5,18);
INSERT INTO atorParticipa VALUES (5,19);
INSERT INTO atorParticipa VALUES (5,20);

commit;


