drop database DBemprestimo;

create database DBemprestimo;

use DBemprestimo;

CREATE TABLE Diretor (
  idDiretor INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  nomeDiretor VARCHAR(50) NOT NULL,
  PRIMARY KEY(idDiretor)
);

CREATE TABLE DVD (
  idDVD INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  tituloPort VARCHAR(70) NULL,
  tituloIng VARCHAR(70) NULL,
  tipo CHAR NOT NULL,
  genero VARCHAR(25) NOT NULL,
  ano INTEGER UNSIGNED NULL,
  PRIMARY KEY(idDVD)
);

CREATE TABLE Amigo (
  cpf VARCHAR(11) NOT NULL,
  nome VARCHAR(45) NOT NULL,
  endereco VARCHAR(60) NOT NULL,
  tel1 VARCHAR(10) NOT NULL,
  tel2 VARCHAR(10) NULL,
  tel3 VARCHAR(10) NULL,
  PRIMARY KEY(cpf)
);

CREATE TABLE Ator (
  idAtor INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  nomeAtor VARCHAR(50) NOT NULL,
  PRIMARY KEY(idAtor)
);

CREATE TABLE Emprestimo (
  idEmprestimo INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  cpf VARCHAR(11) NOT NULL,
  idDVD INTEGER UNSIGNED NOT NULL,
  dataEmprest DATE NOT NULL,
  dataPrev DATE NOT NULL,
  dataDevol DATE NULL,
  PRIMARY KEY(idEmprestimo),
  INDEX Emprestimo_FKIndex1(idDVD),
  INDEX Emprestimo_FKIndex2(cpf),
  FOREIGN KEY(idDVD)
    REFERENCES DVD(idDVD)
      ON DELETE RESTRICT
      ON UPDATE CASCADE,
  FOREIGN KEY(cpf)
    REFERENCES Amigo(cpf)
      ON DELETE RESTRICT
      ON UPDATE CASCADE
);

CREATE TABLE AtorParticipa (
  idDVD INTEGER UNSIGNED NOT NULL,
  idAtor INTEGER UNSIGNED NOT NULL,
  PRIMARY KEY(idDVD, idAtor),
  INDEX DVD_has_Ator_FKIndex1(idDVD),
  INDEX DVD_has_Ator_FKIndex2(idAtor),
  FOREIGN KEY(idDVD)
    REFERENCES DVD(idDVD)
      ON DELETE RESTRICT
      ON UPDATE CASCADE,
  FOREIGN KEY(idAtor)
    REFERENCES Ator(idAtor)
      ON DELETE RESTRICT
      ON UPDATE CASCADE
);

CREATE TABLE DiretorParticipa (
  idDVD INTEGER UNSIGNED NOT NULL,
  idDiretor INTEGER UNSIGNED NOT NULL,
  PRIMARY KEY(idDVD, idDiretor),
  INDEX DVD_has_Diretor_FKIndex1(idDVD),
  INDEX DVD_has_Diretor_FKIndex2(idDiretor),
  FOREIGN KEY(idDVD)
    REFERENCES DVD(idDVD)
      ON DELETE RESTRICT
      ON UPDATE CASCADE,
  FOREIGN KEY(idDiretor)
    REFERENCES Diretor(idDiretor)
      ON DELETE RESTRICT
      ON UPDATE CASCADE
);